#!/bin/sh
cd `dirname $0`
 ROOT_PATH=`pwd`
 java -Xms256M -Xmx1024M -cp $ROOT_PATH:$ROOT_PATH/../lib/systemRoutines.jar:$ROOT_PATH/../lib/userRoutines.jar::.:$ROOT_PATH/filearchive_wfilewait_0_1.jar:$ROOT_PATH/../lib/activation.jar:$ROOT_PATH/../lib/checkArchive.jar:$ROOT_PATH/../lib/commons-compress-1.6.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/filecopy.jar:$ROOT_PATH/../lib/log4j-1.2.15.jar:$ROOT_PATH/../lib/mail-1.4.jar:$ROOT_PATH/../lib/talendzip.jar:$ROOT_PATH/../lib/zip4j_1.3.1.jar: mydemo.filearchive_wfilewait_0_1.FileArchive_wFileWait --context=Default "$@" 